
public interface Book {
	public String bookTitle();
}
