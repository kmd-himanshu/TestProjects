
public class MobileStore {
	public String buyMobile(){
		return "Bought a Mobile Phone";
	}
}
