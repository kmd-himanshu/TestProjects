
public class StoryBook implements Book{
	public String bookTitle() {
		return "HarryPotter";
	}
}
