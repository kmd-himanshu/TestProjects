
public class ProgrammingBook implements Book{
	public String bookTitle() {
		return "spring programming";
	}
}

